/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

var aop = {
    transactionInterceptor : {
        type: "org.nutz.aop.interceptor.TransactionInterceptor"
    },
    log : {
		type : 'org.nutz.aop.interceptor.LoggingMethodInterceptor'
	}
}
